BFS DAY SCRAPBOOK — V2
Oshina ♡ Ashif

This version has NO background music.

Files:
- index.html = the complete website
- 6 JPG files = your photos

To test:
1. Keep all files together in one folder.
2. Open index.html in Chrome.

To put it online:
Use a static website host such as GitHub Pages or Netlify.
Upload the whole folder; the host will give you an https:// link that can be opened in Google Chrome.

Important:
The photos are local files referenced by index.html, so keep them together when uploading.
